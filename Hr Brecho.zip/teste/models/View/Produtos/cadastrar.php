<h1>Cadastrar Produto</h1>
<form method="POST">
    Nome: <input type="text" name="nome"><br>
    Preço: <input type="text" name="preco"><br>
    Descrição: <textarea name="descricao"></textarea><br>
    Imagem: <input type="text" name="imagem"><br>
    <button type="submit">Salvar</button>
</form>