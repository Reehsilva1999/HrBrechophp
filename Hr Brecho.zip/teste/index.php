<?php include 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="pt - BR">
<head>
    <meta charset="UTF-8">
    <title>Brecho Hr roupas femininas</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
     <h1>Hr Brechó online roupas femininas</h1>
    <img src="./img/terceira.lpg.jpg" class="imagem-cabecalho" alt="Imagem do Brechó"> 
</header>
   <main>
    <h2>Categorias</h2>
    <div class="categoria-container">
        <div class="categoria">
            <a href="roupas/blusa.php">
                <img src="img/blusa-de-lã-19.jpg" alt="Blusas">
                <p>Blusas</p>
           </a>
       </div>

<div class="categoria">
    <a href="roupas/calca.php">
        <img src="img/calcas.jpeg" alt="Calças">
        <p>Calças</p>
   </a>
</div>

<div class="categoria">
    <a href="roupas/camisetas.php">
        <img src="img/camisetas.webp" alt="Camisetas">
        <p>Camisetas</p>
   </a>
</div>

<div class="categoria">
    <a href="roupas/vestidos.php">
        <img src="img/vestidos.jpeg" alt="Vestidos">
        <p>Vestidos</p>
   </a>
</div>
   </main>
   
</body>
</html>


<?php include 'includes/footer.php'; ?>