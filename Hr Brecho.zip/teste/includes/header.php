<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>HR Brechó roupas femininas</title>
    <link rel="stylesheet" href="index.css">
</head>


<header>

    <nav>
        <ul>
        <li>
                <a href="index.php">Menu</a>
            </li>
            <li>
                <a href="garimpar.php">Garimpar</a>
            </li>
            <li>
                <a href="mensagem.php">Mensagem</a>
            </li>
            <li>
                <a href="sobre.php">Sobre</a>
            </li>
            <li>
                <a href="contact.php">Contato</a>
            </li>
        
</ul>

</nav>