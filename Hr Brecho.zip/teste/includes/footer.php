<footer>

<p>&copy; 2025 - Hr Brechó online</p>
</footer>
</body>