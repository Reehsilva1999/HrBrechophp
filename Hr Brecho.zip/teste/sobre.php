
<?php include ('includes/header.php'); ?>

<link rel="stylesheet" href="index.css">

<header>
<img src="./img/terceira.lpg.jpg"></img>
</header>

<main>
    <section>
        <h2>Historia do HR Brechó</h2>
        <p>Sobre nós</p>

        <img src="./img/segunda.jpg" class="imagem-central" alt="imagem do brechó">

        <p>
        Somos um casal que acredita em recomeços, boas intenções e em dar uma nova chance às coisas — 
        inclusive às roupas. Nosso brechó nasceu do desejo de empreender juntos, unindo nosso amor pelo estilo, pela sustentabilidade e pela ideia de que cada peça tem uma história para contar.m meio às conversas de fim de tarde e aos sonhos compartilhados, criamos este espaço com carinho, para conectar pessoas e peças únicas. Aqui, tudo é escolhido com cuidado, pensando em quem valoriza autenticidade, economia e consciência.Nosso propósito vai além da moda: queremos inspirar novas formas de consumo, onde vestir-se bem também significa cuidar do mundo e das histórias que queremos construir.Seja bem-vindo(a) ao nosso brechó. Você faz parte dessa nova história com a gente. 💛
</p>
</section>
</main>

<?php('include/footer.php'); ?>
